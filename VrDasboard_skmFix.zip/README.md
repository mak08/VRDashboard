# VR Dashboard
Chrome Extension for calling an online sailing route optimizer


# Notes
Before reporting an issue, please 
- check the user manual (linked in VR Dashboard, also available [here](http://bitweide.de/vrdashboard/manual.html) )
- check the [Chrome web store](https://chrome.google.com/webstore/detail/vr-dashboard/amknkhejaogpekncjekiaolgldbejjan) support page
- check if the issue was already discussed on the [router forum](http://zezo.org/forum.pl)

Thanks!

